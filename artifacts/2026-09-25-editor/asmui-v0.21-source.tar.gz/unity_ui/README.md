# ASMUI · Unity 编辑器界面

用 x86-64 ASM 渲染 Unity 编辑器风格的桌面界面。当前 v0.21 的目标是深色编辑器：层级、场景 / 游戏、检查器、项目 / 控制台、工具栏与菜单。默认简体中文，使用本机的 **LXGW WenKai / 霞鹜文楷**，可即时切换 English。

![中文编辑器预览](artifacts/2026-09-25-editor/editor-zh.png)

```sh
make editor                         # 启动可交互的 SDL3 + Vulkan 窗口
make editor-demo                    # 相同渲染路径，输出 build/editor.png
./build/editor --lang en-US          # 英文界面
```

顶部 `English / 简体中文` 按钮切换语言。也可通过环境变量指定：

```sh
ASMUI_LANG=zh-CN ASMUI_FONT="$HOME/.local/share/fonts/LXGWWenKai-Regular.ttf" make editor
```

点击层级中的对象可切换检查器；立方体的位置、三轴旋转和缩放可编辑。拖动分隔线调整面板，滚轮滚动检查器与项目列表。场景内右键拖动环绕、滚轮缩放，`F` 重置视角，`Q/W/E/R/T/Y` 切换工具外观，`2D` 切换正交视图。播放、暂停、单步和场景 / 游戏标签有状态反馈。`F12` 保存当前画面。

这是编辑器视觉与交互原型；项目资源为内置示例，尚未接入 Unity 项目读写、C# 运行时、资源导入或构建。未接入的菜单项置灰。场景示例使用投影网格和立方体，其他对象用于展示检查器样式。

## 构建与验证

需要 Linux x86-64、C 编译器 / GNU assembler、`make`、`pkg-config`、SDL3、Vulkan 1.3 驱动与头文件、`glslc`、FreeType、HarfBuzz、libpng。视觉检查另需 Python 3 与 Pillow。字体不随源码打包。

```sh
make editor-check                   # ASM 投影/命中、输入、字形与多语言状态
make editor-visual-check            # 实际 Vulkan PNG 回读与布局检查
make editor-smoke                   # 真实窗口、缩放、SDL 中文输入事件
make verify                         # 编辑器与既有渲染核心回归
```

无桌面时可以执行 `editor-demo` 和 `editor-visual-check`，仍然需要可用的 Vulkan 驱动。

多语言设计、字体选择与扩展步骤见 [多语言 UI 方案](docs/LOCALIZATION.md)。视觉参照、验证范围及 ASM/C 边界见 [编辑器实现说明](docs/EDITOR_UI.md)；本轮证据见 [验证记录](artifacts/2026-09-25-editor/REPORT.md)。旧音游场景仍保留为渲染回归样例，运行 `make song-select-demo` 或 `make song-select-sdl-demo`，开发记录见 [历史版本](docs/HISTORY.md)。
