#include "asmui_editor.h"
#include "asmui_font_sdf_ft.h"
#include "asmui_text.h"
#include "asmui_vulkan.h"
#include "asmui_vulkan_texture.h"
#include <SDL3/SDL.h>
#include <SDL3/SDL_vulkan.h>
#include <png.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INPUT_FONT_PAGES 64u
typedef struct FontBank {
    AsmUiFontSdfAtlas *base;
    AsmUiFontSdfAtlas pages[INPUT_FONT_PAGES];
    uint32_t count;
} FontBank;

typedef struct Host {
    SDL_Window *window;
    VkInstance instance;
    VkPhysicalDevice physical;
    VkDevice device;
    VkSurfaceKHR surface;
    VkQueue queue;
    uint32_t family;
    VkCommandPool pool;
    VkCommandBuffer cmd;
    VkFence fence;
    VkSemaphore acquired, done[16];
    VkSwapchainKHR swapchain;
    VkImage images[16];
    uint32_t image_count;
    uint32_t width, height;
    int initialized[16], target_initialized;
    VkFormat swap_format;
    AsmUiVkBackend backend;
    AsmUiVkTargetPool targets;
    AsmUiVkRenderTarget *target;
    VkDescriptorPool descriptors;
    VkSampler sampler;
    AsmUiVkTexture font_texture, white_texture;
    AsmUiVkTexture input_fonts[INPUT_FONT_PAGES];
    VkBuffer readback;
    VkDeviceMemory memory;
    VkMemoryPropertyFlags memory_flags;
} Host;
static void vk_check(VkResult r, const char *s) {
    if (r != VK_SUCCESS) {
        fprintf(stderr, "%s: Vulkan %d\n", s, r);
        exit(1);
    }
}
#define VK(C) vk_check((C), #C)
static void fail(const char *s) {
    fprintf(stderr, "%s\n", s);
    exit(1);
}
static uint32_t *read_spv(const char *path, size_t *bytes) {
    FILE *f = fopen(path, "rb");
    if (!f)
        fail(path);
    if (fseek(f, 0, SEEK_END))
        fail(path);
    long n = ftell(f);
    if (n <= 0 || (n & 3))
        fail(path);
    rewind(f);
    uint32_t *p = malloc((size_t)n);
    if (!p || fread(p, 1, (size_t)n, f) != (size_t)n)
        fail(path);
    fclose(f);
    *bytes = (size_t)n;
    return p;
}
static void barrier(VkCommandBuffer cmd, VkImage image, VkImageLayout before, VkImageLayout after,
                    VkPipelineStageFlags src, VkPipelineStageFlags dst, VkAccessFlags sa,
                    VkAccessFlags da) {
    VkImageMemoryBarrier b = {.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
                              .srcAccessMask = sa,
                              .dstAccessMask = da,
                              .oldLayout = before,
                              .newLayout = after,
                              .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
                              .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
                              .image = image,
                              .subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1}};
    vkCmdPipelineBarrier(cmd, src, dst, 0, 0, NULL, 0, NULL, 1, &b);
}
static void destroy_size(Host *h) {
    if (h->readback)
        vkDestroyBuffer(h->device, h->readback, NULL);
    if (h->memory)
        vkFreeMemory(h->device, h->memory, NULL);
    h->readback = VK_NULL_HANDLE;
    h->memory = VK_NULL_HANDLE;
    asmui_vk_target_pool_destroy(&h->targets);
    for (uint32_t i = 0; i < h->image_count; ++i)
        if (h->done[i])
            vkDestroySemaphore(h->device, h->done[i], NULL);
    memset(h->done, 0, sizeof(h->done));
    h->image_count = 0;
    if (h->swapchain)
        vkDestroySwapchainKHR(h->device, h->swapchain, NULL);
    h->swapchain = VK_NULL_HANDLE;
}
static void create_size(Host *h, uint32_t width, uint32_t height) {
    VK(vkDeviceWaitIdle(h->device));
    destroy_size(h);
    if (h->surface) {
        VkSurfaceCapabilitiesKHR cap;
        VK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(h->physical, h->surface, &cap));
        if (!(cap.supportedUsageFlags & VK_IMAGE_USAGE_TRANSFER_DST_BIT))
            fail("Surface cannot receive a blit");
        if (cap.currentExtent.width != UINT32_MAX) {
            width = cap.currentExtent.width;
            height = cap.currentExtent.height;
        } else {
            width = width < cap.minImageExtent.width   ? cap.minImageExtent.width
                    : width > cap.maxImageExtent.width ? cap.maxImageExtent.width
                                                       : width;
            height = height < cap.minImageExtent.height   ? cap.minImageExtent.height
                     : height > cap.maxImageExtent.height ? cap.maxImageExtent.height
                                                          : height;
        }
        uint32_t nf = 0;
        VK(vkGetPhysicalDeviceSurfaceFormatsKHR(h->physical, h->surface, &nf, NULL));
        if (!nf)
            fail("No surface formats");
        VkSurfaceFormatKHR *fmts = calloc(nf, sizeof(*fmts));
        if (!fmts)
            fail("format allocation");
        VK(vkGetPhysicalDeviceSurfaceFormatsKHR(h->physical, h->surface, &nf, fmts));
        VkSurfaceFormatKHR fmt = fmts[0];
        for (uint32_t i = 0; i < nf; ++i)
            if (fmts[i].format == VK_FORMAT_B8G8R8A8_UNORM ||
                fmts[i].format == VK_FORMAT_R8G8B8A8_UNORM) {
                fmt = fmts[i];
                break;
            }
        free(fmts);
        h->swap_format = fmt.format;
        uint32_t count = cap.minImageCount + 1;
        if (cap.maxImageCount && count > cap.maxImageCount)
            count = cap.maxImageCount;
        VkCompositeAlphaFlagBitsKHR alpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        if (!(cap.supportedCompositeAlpha & alpha)) {
            for (unsigned a = 1; a <= 8; a <<= 1)
                if (cap.supportedCompositeAlpha & a) {
                    alpha = (VkCompositeAlphaFlagBitsKHR)a;
                    break;
                }
        }
        VkSwapchainCreateInfoKHR s = {.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
                                      .surface = h->surface,
                                      .minImageCount = count,
                                      .imageFormat = fmt.format,
                                      .imageColorSpace = fmt.colorSpace,
                                      .imageExtent = {width, height},
                                      .imageArrayLayers = 1,
                                      .imageUsage = VK_IMAGE_USAGE_TRANSFER_DST_BIT,
                                      .imageSharingMode = VK_SHARING_MODE_EXCLUSIVE,
                                      .preTransform = cap.currentTransform,
                                      .compositeAlpha = alpha,
                                      .presentMode = VK_PRESENT_MODE_FIFO_KHR,
                                      .clipped = VK_TRUE};
        VK(vkCreateSwapchainKHR(h->device, &s, NULL, &h->swapchain));
        VK(vkGetSwapchainImagesKHR(h->device, h->swapchain, &h->image_count, NULL));
        if (h->image_count > 16)
            fail("Too many swapchain images");
        VK(vkGetSwapchainImagesKHR(h->device, h->swapchain, &h->image_count, h->images));
        VkSemaphoreCreateInfo sem = {.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        for (uint32_t i = 0; i < h->image_count; ++i)
            VK(vkCreateSemaphore(h->device, &sem, NULL, &h->done[i]));
        memset(h->initialized, 0, sizeof(h->initialized));
    }
    h->width = width;
    h->height = height;
    h->target_initialized = 0;
    asmui_vk_target_pool_init(&h->targets, h->physical, h->device);
    h->target = asmui_vk_target_acquire(&h->targets, width, height, VK_FORMAT_R8G8B8A8_UNORM);
    if (!h->target)
        fail("Offscreen allocation");
    VkBufferCreateInfo bi = {.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
                             .size = (VkDeviceSize)width * height * 4,
                             .usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                             .sharingMode = VK_SHARING_MODE_EXCLUSIVE};
    VK(vkCreateBuffer(h->device, &bi, NULL, &h->readback));
    VkMemoryRequirements req;
    vkGetBufferMemoryRequirements(h->device, h->readback, &req);
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(h->physical, &mp);
    uint32_t mt = UINT32_MAX;
    for (uint32_t i = 0; i < mp.memoryTypeCount; ++i)
        if ((req.memoryTypeBits & (1u << i)) &&
            (mp.memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) {
            mt = i;
            if (mp.memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)
                break;
        }
    if (mt == UINT32_MAX)
        fail("No readback memory");
    h->memory_flags = mp.memoryTypes[mt].propertyFlags;
    VkMemoryAllocateInfo ma = {.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
                               .allocationSize = req.size,
                               .memoryTypeIndex = mt};
    VK(vkAllocateMemory(h->device, &ma, NULL, &h->memory));
    VK(vkBindBufferMemory(h->device, h->readback, h->memory, 0));
}
static void init_host(Host *h, int headless, uint32_t w, uint32_t ht, AsmUiFontSdfAtlas *atlas) {
    const char *const *exts = NULL;
    uint32_t ext_count = 0;
    if (!headless) {
        if (!SDL_Init(SDL_INIT_VIDEO))
            fail(SDL_GetError());
        h->window = SDL_CreateWindow("unity_ui - Unity Editor", (int)w, (int)ht,
                                     SDL_WINDOW_VULKAN | SDL_WINDOW_RESIZABLE);
        if (!h->window)
            fail(SDL_GetError());
        SDL_SetWindowMinimumSize(h->window, 1024, 680);
        exts = SDL_Vulkan_GetInstanceExtensions(&ext_count);
        if (!exts)
            fail(SDL_GetError());
    }
    VkApplicationInfo ai = {.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
                            .pApplicationName = "ASMUI Editor",
                            .applicationVersion = VK_MAKE_VERSION(0, 21, 0),
                            .pEngineName = "ASMUI",
                            .apiVersion = VK_API_VERSION_1_3};
    VkInstanceCreateInfo ici = {.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
                                .pApplicationInfo = &ai,
                                .enabledExtensionCount = ext_count,
                                .ppEnabledExtensionNames = exts};
    VK(vkCreateInstance(&ici, NULL, &h->instance));
    if (h->window && !SDL_Vulkan_CreateSurface(h->window, h->instance, NULL, &h->surface))
        fail(SDL_GetError());
    uint32_t n = 0;
    VK(vkEnumeratePhysicalDevices(h->instance, &n, NULL));
    if (!n)
        fail("No Vulkan device");
    VkPhysicalDevice *devs = calloc(n, sizeof(*devs));
    if (!devs)
        fail("device allocation");
    VK(vkEnumeratePhysicalDevices(h->instance, &n, devs));
    for (uint32_t d = 0; d < n && !h->physical; ++d) {
        VkPhysicalDeviceVulkan13Features f13 = {
            .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};
        VkPhysicalDeviceFeatures2 f2 = {.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2,
                                        .pNext = &f13};
        vkGetPhysicalDeviceFeatures2(devs[d], &f2);
        if (!f13.dynamicRendering)
            continue;
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(devs[d], &qn, NULL);
        VkQueueFamilyProperties *qs = calloc(qn, sizeof(*qs));
        if (!qs)
            fail("queue allocation");
        vkGetPhysicalDeviceQueueFamilyProperties(devs[d], &qn, qs);
        for (uint32_t q = 0; q < qn; ++q) {
            VkBool32 present = VK_TRUE;
            if (h->surface)
                VK(vkGetPhysicalDeviceSurfaceSupportKHR(devs[d], q, h->surface, &present));
            if ((qs[q].queueFlags & VK_QUEUE_GRAPHICS_BIT) && present) {
                h->physical = devs[d];
                h->family = q;
                break;
            }
        }
        free(qs);
    }
    free(devs);
    if (!h->physical)
        fail("Vulkan 1.3 dynamic rendering required");
    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(h->physical, &props);
    printf("Editor GPU: %s\n", props.deviceName);
    float priority = 1;
    VkDeviceQueueCreateInfo qi = {.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
                                  .queueFamilyIndex = h->family,
                                  .queueCount = 1,
                                  .pQueuePriorities = &priority};
    VkPhysicalDeviceVulkan13Features f13 = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES,
        .dynamicRendering = VK_TRUE};
    const char *swap_ext = VK_KHR_SWAPCHAIN_EXTENSION_NAME;
    VkDeviceCreateInfo di = {.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
                             .pNext = &f13,
                             .queueCreateInfoCount = 1,
                             .pQueueCreateInfos = &qi,
                             .enabledExtensionCount = h->surface ? 1u : 0u,
                             .ppEnabledExtensionNames = h->surface ? &swap_ext : NULL};
    VK(vkCreateDevice(h->physical, &di, NULL, &h->device));
    vkGetDeviceQueue(h->device, h->family, 0, &h->queue);
    VkCommandPoolCreateInfo pi = {.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
                                  .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
                                  .queueFamilyIndex = h->family};
    VK(vkCreateCommandPool(h->device, &pi, NULL, &h->pool));
    VkCommandBufferAllocateInfo ca = {.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
                                      .commandPool = h->pool,
                                      .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
                                      .commandBufferCount = 1};
    VK(vkAllocateCommandBuffers(h->device, &ca, &h->cmd));
    VkFenceCreateInfo fi = {.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
                            .flags = VK_FENCE_CREATE_SIGNALED_BIT};
    VK(vkCreateFence(h->device, &fi, NULL, &h->fence));
    VkSemaphoreCreateInfo si = {.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    VK(vkCreateSemaphore(h->device, &si, NULL, &h->acquired));
    if (!asmui_vk_init_streaming(&h->backend, h->physical, h->device,
                                 EDITOR_MAX_DRAWS + EDITOR_MAX_NODES))
        fail("ASM vertex stream init");
    size_t vb, fb;
    uint32_t *vs = read_spv("build/shaders/ui.vert.spv", &vb),
             *fs = read_spv("build/shaders/ui.frag.spv", &fb);
    if (!asmui_vk_create_pipeline_pack(&h->backend, VK_FORMAT_R8G8B8A8_UNORM, vs, vb, fs, fb))
        fail("Editor pipelines");
    free(vs);
    free(fs);
    VkDescriptorPoolSize ps = {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 2 + INPUT_FONT_PAGES};
    VkDescriptorPoolCreateInfo dp = {.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO,
                                     .maxSets = 2 + INPUT_FONT_PAGES,
                                     .poolSizeCount = 1,
                                     .pPoolSizes = &ps};
    VK(vkCreateDescriptorPool(h->device, &dp, NULL, &h->descriptors));
    VkSamplerCreateInfo sci = {.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO,
                               .magFilter = VK_FILTER_LINEAR,
                               .minFilter = VK_FILTER_LINEAR,
                               .mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST,
                               .addressModeU = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE,
                               .addressModeV = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE,
                               .addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE};
    VK(vkCreateSampler(h->device, &sci, NULL, &h->sampler));
    const unsigned char white[] = {255, 255, 255, 255};
    if (!asmui_vk_texture_upload_rgba8(h->physical, h->device, h->queue, h->pool, white, 1, 1,
                                       &h->white_texture) ||
        !asmui_vk_texture_upload_rgba8(h->physical, h->device, h->queue, h->pool, atlas->rgba,
                                       atlas->width, atlas->height, &h->font_texture))
        fail("Editor texture upload");
    if (!asmui_vk_alloc_texture_set(&h->backend, h->descriptors, 0, h->white_texture.view,
                                    h->sampler, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL) ||
        !asmui_vk_alloc_texture_set(&h->backend, h->descriptors, 1, h->font_texture.view,
                                    h->sampler, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL))
        fail("Editor descriptors");
    asmui_vk_set_white_texture_set(&h->backend, h->backend.texture_sets[0]);
    create_size(h, w, ht);
}
static void capture(Host *h, const char *path) {
    VK(vkWaitForFences(h->device, 1, &h->fence, VK_TRUE, UINT64_MAX));
    void *p = NULL;
    VK(vkMapMemory(h->device, h->memory, 0, VK_WHOLE_SIZE, 0, &p));
    if (!(h->memory_flags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
        VkMappedMemoryRange r = {.sType = VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE,
                                 .memory = h->memory,
                                 .size = VK_WHOLE_SIZE};
        VK(vkInvalidateMappedMemoryRanges(h->device, 1, &r));
    }
    png_image im;
    memset(&im, 0, sizeof(im));
    im.version = PNG_IMAGE_VERSION;
    im.width = h->width;
    im.height = h->height;
    im.format = PNG_FORMAT_RGBA;
    if (!png_image_write_to_file(&im, path, 0, p, 0, NULL))
        fail(im.message);
    png_image_free(&im);
    vkUnmapMemory(h->device, h->memory);
    printf("Editor screenshot: %s (%ux%u)\n", path, h->width, h->height);
}

static int font_lookup(uint32_t id, AsmUiHbAtlasGlyph *out, void *user) {
    FontBank *bank = user;
    if (asmui_font_sdf_lookup(id, out, bank->base))
        return 1;
    for (uint32_t i = 0; i < bank->count; ++i)
        if (asmui_font_sdf_lookup(id, out, &bank->pages[i]))
            return 1;
    return 0;
}
static int atlas_has_text(FontBank *bank, const char *text) {
    AsmUiFontSdfAtlas *atlas = bank->base;
    hb_buffer_t *b = hb_buffer_create();
    hb_buffer_add_utf8(b, text, -1, 0, -1);
    hb_buffer_guess_segment_properties(b);
    hb_shape(atlas->hb_font, b, NULL, 0);
    unsigned n;
    hb_glyph_info_t *g = hb_buffer_get_glyph_infos(b, &n);
    int ok = 1;
    for (unsigned i = 0; i < n; ++i) {
        hb_glyph_extents_t ext;
        AsmUiHbAtlasGlyph glyph;
        if (hb_font_get_glyph_extents(atlas->hb_font, g[i].codepoint, &ext) && ext.width &&
            ext.height && !font_lookup(g[i].codepoint, &glyph, bank)) {
            ok = 0;
            break;
        }
    }
    hb_buffer_destroy(b);
    return ok;
}
static void extend_font(Host *h, FontBank *bank, const EditorState *e) {
    const char *s = e->focus == 100 ? e->search : e->edit;
    char shown[sizeof(e->search) + sizeof(e->composition)];
    snprintf(shown, sizeof(shown), "%s%s", s, e->composition);
    if (atlas_has_text(bank, shown))
        return;
    uint64_t start = SDL_GetTicksNS();
    if (bank->count == INPUT_FONT_PAGES) {
        fprintf(stderr, "Input glyph pages full; missing glyphs use a box\n");
        return;
    }
    const char *samples[] = {shown};
    AsmUiFontSdfAtlas *next = &bank->pages[bank->count];
    uint32_t resource = 2 + bank->count;
    int built = asmui_font_sdf_build_missing(next, editor_font(), resource, 64, samples, 1,
                                             font_lookup, bank);
    if (!built) {
        fprintf(stderr, "Input glyph atlas extension failed\n");
        return;
    }
    AsmUiVkTexture *texture = &h->input_fonts[bank->count];
    if (!asmui_vk_texture_upload_rgba8(h->physical, h->device, h->queue, h->pool, next->rgba,
                                       next->width, next->height, texture))
        fail("Input glyph texture upload");
    if (!asmui_vk_alloc_texture_set(&h->backend, h->descriptors, resource, texture->view,
                                    h->sampler, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL))
        fail("Input glyph descriptor allocation");
    ++bank->count;
    printf("Input glyph page %u: %u new glyphs, missing=%u, build+upload=%.3f ms\n", bank->count,
           next->glyph_count, next->missing_glyph_count, (SDL_GetTicksNS() - start) / 1e6);
}
static float measure_text(const char *text, float pixels, void *user) {
    hb_font_t *font = user;
    hb_buffer_t *buffer = hb_buffer_create();
    hb_buffer_add_utf8(buffer, text, -1, 0, -1);
    hb_buffer_guess_segment_properties(buffer);
    hb_shape(font, buffer, NULL, 0);
    unsigned n;
    hb_glyph_position_t *p = hb_buffer_get_glyph_positions(buffer, &n);
    float advance = 0;
    int scale = 1;
    hb_font_get_scale(font, &scale, NULL);
    for (unsigned i = 0; i < n; ++i)
        advance += p[i].x_advance * pixels / (float)scale;
    hb_buffer_destroy(buffer);
    return advance;
}
static void text_input_area(Host *h, const EditorState *e) {
    if (!h->window)
        return;
    if (e->focus < 0) {
        if (SDL_TextInputActive(h->window))
            SDL_StopTextInput(h->window);
        return;
    }
    int ww, hh;
    SDL_GetWindowSize(h->window, &ww, &hh);
    float sx = (float)ww / h->width, sy = (float)hh / h->height;
    SDL_Rect r = {(int)(e->input_rect.x * sx), (int)(e->input_rect.y * sy),
                  (int)(e->input_rect.w * sx), (int)(e->input_rect.h * sy)};
    SDL_SetTextInputArea(h->window, &r, (int)(e->caret_offset * sx));
    if (!SDL_TextInputActive(h->window))
        SDL_StartTextInput(h->window);
}
/* A shared render path produces both the native window and lossless readback.
   Headless visual checks therefore exercise exactly the same ASM/UI renderer. */
static int draw(Host *h, AsmUiContext *ctx, AsmUiBatch *batches, uint32_t count, int screenshot) {
    VK(vkWaitForFences(h->device, 1, &h->fence, VK_TRUE, UINT64_MAX));
    uint32_t index = 0;
    if (h->swapchain) {
        VkResult r = vkAcquireNextImageKHR(h->device, h->swapchain, UINT64_MAX, h->acquired,
                                           VK_NULL_HANDLE, &index);
        if (r == VK_ERROR_OUT_OF_DATE_KHR)
            return -1;
        if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR)
            vk_check(r, "acquire");
    }
    if (asmui_vk_upload(ctx, &h->backend) != ctx->draw_count * 4u)
        fail("Editor vertex capacity");
    VK(vkResetCommandBuffer(h->cmd, 0));
    VkCommandBufferBeginInfo cb = {.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
                                   .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT};
    VK(vkBeginCommandBuffer(h->cmd, &cb));
    barrier(
        h->cmd, h->target->image,
        h->target_initialized ? VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL : VK_IMAGE_LAYOUT_UNDEFINED,
        VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
        h->target_initialized ? VK_PIPELINE_STAGE_TRANSFER_BIT : VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        h->target_initialized ? VK_ACCESS_TRANSFER_READ_BIT : 0,
        VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT);
    VkRenderingAttachmentInfo a = {.sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO,
                                   .imageView = h->target->view,
                                   .imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
                                   .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
                                   .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
                                   .clearValue = {.color = {.float32 = {0, 0, 0, 1}}}};
    VkRenderingInfo ri = {.sType = VK_STRUCTURE_TYPE_RENDERING_INFO,
                          .renderArea = {{0, 0}, {h->width, h->height}},
                          .layerCount = 1,
                          .colorAttachmentCount = 1,
                          .pColorAttachments = &a};
    vkCmdBeginRendering(h->cmd, &ri);
    asmui_vk_record_images(h->cmd, ctx, batches, count, &h->backend, h->width, h->height);
    vkCmdEndRendering(h->cmd);
    barrier(h->cmd, h->target->image, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
            VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
            VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
            VK_ACCESS_TRANSFER_READ_BIT);
    h->target_initialized = 1;
    if (screenshot) {
        VkBufferImageCopy copy = {.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1},
                                  .imageExtent = {h->width, h->height, 1}};
        vkCmdCopyImageToBuffer(h->cmd, h->target->image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                               h->readback, 1, &copy);
        VkBufferMemoryBarrier b = {.sType = VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER,
                                   .srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT,
                                   .dstAccessMask = VK_ACCESS_HOST_READ_BIT,
                                   .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
                                   .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
                                   .buffer = h->readback,
                                   .size = VK_WHOLE_SIZE};
        vkCmdPipelineBarrier(h->cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT, 0,
                             0, NULL, 1, &b, 0, NULL);
    }
    if (h->swapchain) {
        barrier(h->cmd, h->images[index],
                h->initialized[index] ? VK_IMAGE_LAYOUT_PRESENT_SRC_KHR : VK_IMAGE_LAYOUT_UNDEFINED,
                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT, 0, VK_ACCESS_TRANSFER_WRITE_BIT);
        VkImageBlit b = {.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1},
                         .srcOffsets = {{0, 0, 0}, {(int)h->width, (int)h->height, 1}},
                         .dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1},
                         .dstOffsets = {{0, 0, 0}, {(int)h->width, (int)h->height, 1}}};
        vkCmdBlitImage(h->cmd, h->target->image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                       h->images[index], VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &b,
                       VK_FILTER_NEAREST);
        barrier(h->cmd, h->images[index], VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                VK_IMAGE_LAYOUT_PRESENT_SRC_KHR, VK_PIPELINE_STAGE_TRANSFER_BIT,
                VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, VK_ACCESS_TRANSFER_WRITE_BIT, 0);
        h->initialized[index] = 1;
    }
    VK(vkEndCommandBuffer(h->cmd));
    VK(vkResetFences(h->device, 1, &h->fence));
    VkPipelineStageFlags stage = VK_PIPELINE_STAGE_TRANSFER_BIT;
    VkSubmitInfo si = {.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
                       .waitSemaphoreCount = h->swapchain ? 1u : 0u,
                       .pWaitSemaphores = h->swapchain ? &h->acquired : NULL,
                       .pWaitDstStageMask = &stage,
                       .commandBufferCount = 1,
                       .pCommandBuffers = &h->cmd,
                       .signalSemaphoreCount = h->swapchain ? 1u : 0u,
                       .pSignalSemaphores = h->swapchain ? &h->done[index] : NULL};
    VK(vkQueueSubmit(h->queue, 1, &si, h->fence));
    if (h->swapchain) {
        VkPresentInfoKHR p = {.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
                              .waitSemaphoreCount = 1,
                              .pWaitSemaphores = &h->done[index],
                              .swapchainCount = 1,
                              .pSwapchains = &h->swapchain,
                              .pImageIndices = &index};
        VkResult r = vkQueuePresentKHR(h->queue, &p);
        if (r == VK_ERROR_OUT_OF_DATE_KHR || r == VK_SUBOPTIMAL_KHR)
            return 0;
        vk_check(r, "present");
    }
    return 1;
}
static void destroy_host(Host *h) {
    VK(vkDeviceWaitIdle(h->device));
    destroy_size(h);
    asmui_vk_texture_destroy(h->device, &h->font_texture);
    for (uint32_t i = 0; i < INPUT_FONT_PAGES; ++i)
        asmui_vk_texture_destroy(h->device, &h->input_fonts[i]);
    asmui_vk_texture_destroy(h->device, &h->white_texture);
    vkDestroySampler(h->device, h->sampler, NULL);
    vkDestroyDescriptorPool(h->device, h->descriptors, NULL);
    asmui_vk_destroy_pipeline_pack(&h->backend);
    asmui_vk_destroy_streaming(&h->backend);
    vkDestroyFence(h->device, h->fence, NULL);
    vkDestroySemaphore(h->device, h->acquired, NULL);
    vkDestroyCommandPool(h->device, h->pool, NULL);
    vkDestroyDevice(h->device, NULL);
    if (h->surface)
        vkDestroySurfaceKHR(h->instance, h->surface, NULL);
    vkDestroyInstance(h->instance, NULL);
    if (h->window) {
        SDL_DestroyWindow(h->window);
        SDL_Quit();
    }
}
static void preview_state(EditorState *e, const char *state) {
    if (!strcmp(state, "camera"))
        e->selected = 0;
    else if (!strcmp(state, "console"))
        e->console = 1;
    else if (!strcmp(state, "play"))
        e->playing = 1;
    else if (!strcmp(state, "menu"))
        e->menu = 0;
    else if (!strcmp(state, "search")) {
        e->focus = 100;
        editor_text(e, "测试立方体");
    } else if (!strcmp(state, "ime")) {
        e->focus = 100;
        editor_composition(e, "测试输入");
    } else if (!strcmp(state, "rotated")) {
        e->rotation[0] = 25;
        e->rotation[1] = 35;
        e->rotation[2] = 15;
    } else if (!strcmp(state, "game"))
        e->game = 1;
    else if (!strcmp(state, "2d"))
        e->two_d = 1;
    else if (strcmp(state, "default"))
        fail("Unknown editor state");
}
typedef struct Preview {
    const char *name, *state;
    EditorLocale locale;
    uint32_t width, height;
} Preview;
static const Preview previews[] = {
    {"editor-zh", "default", EDITOR_ZH_CN, 1440, 900},
    {"editor-en", "default", EDITOR_EN_US, 1440, 900},
    {"editor-compact", "default", EDITOR_ZH_CN, 1024, 680},
    {"editor-compact-en", "default", EDITOR_EN_US, 1024, 680},
    {"editor-menu", "menu", EDITOR_ZH_CN, 1440, 900},
    {"editor-camera", "camera", EDITOR_ZH_CN, 1440, 900},
    {"editor-console", "console", EDITOR_ZH_CN, 1440, 900},
    {"editor-2d", "2d", EDITOR_ZH_CN, 1440, 900},
    {"editor-game", "game", EDITOR_ZH_CN, 1440, 900},
    {"editor-rotated", "rotated", EDITOR_ZH_CN, 1440, 900},
    {"editor-ime", "ime", EDITOR_ZH_CN, 1440, 900},
    {"editor-search", "search", EDITOR_ZH_CN, 1440, 900},
    {"editor-large", "default", EDITOR_ZH_CN, 1920, 1080},
};
int main(int argc, char **argv) {
    int headless = 0, smoke = 0;
    EditorLocale locale = EDITOR_ZH_CN;
    const char *locale_env = getenv("ASMUI_LANG");
    if (locale_env && *locale_env && !editor_locale_parse(locale_env, &locale))
        fail("ASMUI_LANG must be zh-CN or en-US");
    uint32_t width = 1440, height = 900, limit = 0;
    const char *output = "build/editor.png", *state = "default", *gallery = NULL;
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--headless"))
            headless = 1;
        else if (!strcmp(argv[i], "--lang") && i + 1 < argc) {
            if (!editor_locale_parse(argv[++i], &locale))
                fail("--lang must be zh-CN or en-US");
        } else if (!strcmp(argv[i], "--smoke"))
            smoke = 1;
        else if (!strcmp(argv[i], "--frames") && i + 1 < argc)
            limit = (uint32_t)strtoul(argv[++i], NULL, 10);
        else if (!strcmp(argv[i], "--output") && i + 1 < argc)
            output = argv[++i];
        else if (!strcmp(argv[i], "--gallery") && i + 1 < argc)
            gallery = argv[++i];
        else if (!strcmp(argv[i], "--state") && i + 1 < argc)
            state = argv[++i];
        else if (!strcmp(argv[i], "--size") && i + 2 < argc) {
            width = (uint32_t)strtoul(argv[++i], NULL, 10);
            height = (uint32_t)strtoul(argv[++i], NULL, 10);
        } else {
            fprintf(stderr,
                    "Usage: %s [--headless] [--size W H] [--frames N] [--smoke] [--lang "
                    "zh-CN|en-US] [--state "
                    "default|camera|console|play|menu|search|ime|rotated|game|2d] [--output "
                    "FILE.png] [--gallery DIR]\n",
                    argv[0]);
            return 2;
        }
    }
    if (width < 1024 || height < 680 || width > 3840 || height > 2160)
        fail("Editor size must be 1024x680 .. 3840x2160");
    if (headless && !limit)
        limit = 1;
    if (smoke && !limit)
        limit = 90;
    if (gallery) {
        headless = 1;
        smoke = 0;
        limit = sizeof(previews) / sizeof(previews[0]);
    }
    AsmUiFontSdfAtlas atlas = {0};
    size_t ns;
    const char *const *samples = editor_font_samples(&ns);
    const char *font = editor_font();
    if (!font || !asmui_font_sdf_build(&atlas, font, 1, 64, samples, ns) ||
        atlas.missing_glyph_count)
        fail("Editor font build failed; set ASMUI_FONT");
    printf("Editor font: %s (%u glyphs)\n", font, atlas.glyph_count);
    AsmUiHbShaper shaper = asmui_font_sdf_shaper(&atlas);
    FontBank fonts = {.base = &atlas};
    shaper.lookup = font_lookup;
    shaper.lookup_user = &fonts;
    Host host = {0};
    init_host(&host, headless, width, height, &atlas);
    EditorState e;
    editor_init(&e, (float)host.width, (float)host.height);
    e.locale = locale;
    printf("Editor language: %s\n", editor_locale_name(e.locale));
    preview_state(&e, state);
    static AsmUiNode nodes[EDITOR_MAX_NODES];
    static AsmUiDrawCmd raw[EDITOR_MAX_DRAWS], expanded[EDITOR_MAX_DRAWS];
    static AsmUiBatch batches[EDITOR_MAX_DRAWS];
    static AsmUiGlyphQuad glyphs[2048];
    AsmUiContext ctx;
    asm_ui_init(&ctx, nodes, EDITOR_MAX_NODES, raw, EDITOR_MAX_DRAWS, NULL, 0);
    int running = 1;
    int font_dirty = e.focus >= 0;
    uint32_t frames = 0, last_draws = 0, last_batches = 0;
    uint64_t start = SDL_GetTicksNS();
    while (running && (!limit || frames < limit)) {
        char gallery_path[4096];
        const char *frame_output = output;
        if (gallery) {
            const Preview *p = &previews[frames];
            if (host.width != p->width || host.height != p->height)
                create_size(&host, p->width, p->height);
            editor_init(&e, host.width, host.height);
            e.locale = p->locale;
            preview_state(&e, p->state);
            font_dirty = e.focus >= 0;
            int n = snprintf(gallery_path, sizeof(gallery_path), "%s/%s.png", gallery, p->name);
            if (n < 0 || (size_t)n >= sizeof(gallery_path))
                fail("Gallery path too long");
            frame_output = gallery_path;
        }
        int resize = 0, screenshot = headless || (limit && frames + 1 == limit);
        SDL_Event ev;
        if (!headless)
            while (SDL_PollEvent(&ev)) {
                if (ev.type == SDL_EVENT_QUIT)
                    running = 0;
                else if (ev.type == SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED)
                    resize = 1;
                else if (ev.type == SDL_EVENT_MOUSE_MOTION) {
                    int ww, hh;
                    SDL_GetWindowSize(host.window, &ww, &hh);
                    editor_motion(&e, ev.motion.x * host.width / (float)ww,
                                  ev.motion.y * host.height / (float)hh);
                } else if (ev.type == SDL_EVENT_MOUSE_BUTTON_DOWN ||
                           ev.type == SDL_EVENT_MOUSE_BUTTON_UP) {
                    int ww, hh;
                    SDL_GetWindowSize(host.window, &ww, &hh);
                    if (ev.type == SDL_EVENT_MOUSE_BUTTON_DOWN && e.focus >= 0)
                        SDL_ClearComposition(host.window);
                    if (editor_pointer(&e, ev.button.x * host.width / (float)ww,
                                       ev.button.y * host.height / (float)hh, ev.button.button,
                                       ev.type == SDL_EVENT_MOUSE_BUTTON_DOWN))
                        running = 0;
                } else if (ev.type == SDL_EVENT_MOUSE_WHEEL)
                    editor_wheel(&e, ev.wheel.direction == SDL_MOUSEWHEEL_FLIPPED ? -ev.wheel.y
                                                                                  : ev.wheel.y);
                else if (ev.type == SDL_EVENT_TEXT_INPUT) {
                    editor_text(&e, ev.text.text);
                    font_dirty = 1;
                } else if (ev.type == SDL_EVENT_TEXT_EDITING) {
                    editor_composition(&e, ev.edit.text);
                    font_dirty = 1;
                } else if (ev.type == SDL_EVENT_KEY_DOWN) {
                    if (ev.key.key == SDLK_F12)
                        screenshot = 1;
                    else {
                        if (ev.key.key == SDLK_ESCAPE)
                            SDL_ClearComposition(host.window);
                        editor_key(&e, (int)ev.key.key, (ev.key.mod & SDL_KMOD_CTRL) != 0);
                    }
                }
            }
        if (!running)
            break;
        if (smoke) {
            if (frames == 10) {
                editor_pointer(&e, 75, 165, 1, 1);
                editor_pointer(&e, 75, 165, 1, 0);
            }
            if (frames == 20)
                editor_key(&e, 'p', 1);
            if (frames == 30 && !headless) {
                SDL_SetWindowSize(host.window, 1280, 800);
                resize = 1;
            }
            if (frames == 40)
                e.console = 1;
            if (frames == 50) {
                e.console = 0;
                e.selected = 3;
                e.asset = -1;
            }
            if (frames == 60) {
                e.menu = 0;
            }
            if (frames == 70)
                e.menu = -1;
            if (frames == 74) {
                e.focus = 100;
                if (headless) {
                    editor_composition(&e, "测试输入");
                    font_dirty = 1;
                } else {
                    SDL_Event event = {0};
                    event.type = SDL_EVENT_TEXT_EDITING;
                    event.edit.windowID = SDL_GetWindowID(host.window);
                    event.edit.text = "测试输入";
                    if (!SDL_PushEvent(&event))
                        fail("Smoke preedit event");
                }
            }
            if (frames == 77) {
                if (strcmp(e.composition, "测试输入") || !atlas_has_text(&fonts, e.composition))
                    fail("Smoke preedit/glyph coverage");
            }
            if (frames == 78) {
                if (headless) {
                    editor_text(&e, "立方体");
                    font_dirty = 1;
                } else {
                    SDL_Event event = {0};
                    event.type = SDL_EVENT_TEXT_INPUT;
                    event.text.windowID = SDL_GetWindowID(host.window);
                    event.text.text = "立方体";
                    if (!SDL_PushEvent(&event))
                        fail("Smoke input event");
                }
            }
            if (frames == 81) {
                if (strcmp(e.search, "立方体") || e.composition[0])
                    fail("Smoke committed UTF-8 text");
                printf("SDL text input: preedit, dynamic glyphs and Chinese commit OK\n");
            }
            if (frames == 82) {
                editor_key(&e, 'a', 1);
                editor_key(&e, 13, 0);
            }
        }
        if (resize) {
            int ww, hh;
            SDL_GetWindowSizeInPixels(host.window, &ww, &hh);
            if (ww < 1 || hh < 1) {
                SDL_Delay(20);
                continue;
            }
            create_size(&host, (uint32_t)ww, (uint32_t)hh);
            editor_resize(&e, (float)host.width, (float)host.height);
        }
        /* The fence also protects the persistently mapped ASM vertex stream. */
        VK(vkWaitForFences(host.device, 1, &host.fence, VK_TRUE, UINT64_MAX));
        if (font_dirty && e.focus >= 0)
            extend_font(&host, &fonts, &e);
        font_dirty = 0;
        e.measure_text = measure_text;
        e.measure_user = atlas.hb_font;
        ctx.node_count = editor_build(&e, nodes, EDITOR_MAX_NODES, atlas.px_range);
        text_input_area(&host, &e);
        if (ctx.node_count >= EDITOR_MAX_NODES)
            fail("Editor node capacity");
        asm_ui_set_viewport(&ctx, e.width, e.height);
        asm_ui_begin_frame(&ctx, 1.f / 60.f);
        asm_ui_layout(&ctx);
        asm_ui_build_drawlist(&ctx);
        editor_patch_quads(&e, &ctx);
        AsmUiContext render = ctx;
        render.draws = expanded;
        render.draw_count = asmui_expand_text_stream(&ctx, expanded, EDITOR_MAX_DRAWS,
                                                     asmui_hb_shape, &shaper, glyphs, 2048);
        if (!render.draw_count || render.draw_count >= EDITOR_MAX_DRAWS)
            fail("Editor text expansion");
        last_draws = render.draw_count;
        last_batches = asm_ui_build_batches(&render, batches, EDITOR_MAX_DRAWS);
        int presented = draw(&host, &render, batches, last_batches, screenshot);
        if (screenshot && presented >= 0)
            capture(&host, frame_output);
        if (presented <= 0 && !headless) {
            int ww, hh;
            SDL_GetWindowSizeInPixels(host.window, &ww, &hh);
            if (ww > 0 && hh > 0) {
                create_size(&host, (uint32_t)ww, (uint32_t)hh);
                editor_resize(&e, (float)host.width, (float)host.height);
            }
            if (presented < 0) {
                SDL_Delay(20);
                continue;
            }
        }
        ++frames;
        if (e.playing && !e.paused)
            ++e.frame;
    }
    printf("Editor rendered: frames=%u nodes=%u text=%u draws=%u batches=%u elapsed=%.3f s\n",
           frames, e.node_count, e.text_count, last_draws, last_batches,
           (SDL_GetTicksNS() - start) / 1e9);
    destroy_host(&host);
    for (uint32_t i = 0; i < fonts.count; ++i)
        asmui_font_sdf_destroy(&fonts.pages[i]);
    asmui_font_sdf_destroy(&atlas);
    return frames ? 0 : 1;
}
