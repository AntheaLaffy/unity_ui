# 多语言 UI 方案

当前交付 `zh-CN`（默认）和 `en-US` 两套编辑器界面，使用同一布局与同一套 ASM 绘制代码。中文是正常使用路径，包含菜单、面板、检查器组件、示例对象、项目分类和状态栏；资源文件名、数值与用户输入保留原文。

## 选择语言与字体

| 设置 | 优先级 / 行为 |
| --- | --- |
| `--lang zh-CN` / `--lang en-US` | 覆盖环境变量；`zh` / `en` 也可解析 |
| `ASMUI_LANG` | 未提供命令行语言时生效 |
| 工具栏语言按钮 | 立即切换，保留面板和对象状态 |
| 未设置语言 | 简体中文；不依赖终端 `LANG=C.UTF-8` |
| `ASMUI_FONT` | 指定可读的字体文件 |
| 用户字体目录 | 优先 `$XDG_DATA_HOME/fonts/LXGWWenKai-Regular.ttf`，其次 `$HOME/.local/share/fonts/LXGWWenKai-Regular.ttf` |
| 系统回退 | 按已有字体查找器优先寻找 Noto CJK，再寻找其他系统字体 |

本机使用 `/home/fuurin/.local/share/fonts/LXGWWenKai-Regular.ttf`。中英文统一用 LXGW，常规标签 13 px，小字 11 px，单行控件约 18–24 px。启动会检查中英文本是否缺字；回退字体覆盖不足时会明确报错，不能以空白字符冒充中文支持。

字体由用户安装，仓库不复制字体文件。以上是**文件级字体回退**；混用多个字体覆盖单个字符串的字形级回退尚未实现。

## 文案、排版与渲染

`demo/editor_i18n.c` 集中维护英语消息键与中文译文。`editor_localize()` 在创建文字节点时选择译文，未匹配的动态内容直接保留。两种语言的界面文案和常见拉丁连字一起预载，避免切换语言时重新生成图集。

渲染顺序：

1. UTF-8 文本与当前语言进入界面节点。
2. HarfBuzz 按字体排版，输出字形 ID、偏移和 advance。
3. FreeType 图集提供字形平面尺寸、SDF 纹理与 UV。
4. ASM 执行布局、裁剪、字形几何变换、相邻批合并与 GPU 顶点打包。
5. Vulkan 在实际窗口或离屏目标绘制，两者使用同一路径。

面板宽度与字段宽度按可用空间计算；长文字裁剪在本控件内。编辑中的单行文本超宽时显示末尾，光标与输入法候选区域使用实际 HarfBuzz advance。项目资源缩略图会随宽度换行。

## 中文输入

SDL `TEXT_EDITING` 显示带下划线的预编辑文本，`TEXT_INPUT` 提交 UTF-8。输入框聚焦时启动文本输入并设置候选区域，失焦后关闭；预编辑期间 Enter / Backspace 交给输入法处理，点击其他控件或 Escape 取消预编辑。

已提交字段最多 63 字节，预编辑最多 127 字节，均在完整 Unicode 码点边界截断；退格删除完整码点并拒绝非法 UTF-8。当前提供末尾输入、退格和 Ctrl+A 清空；尚不含任意光标移动、复杂选区与剪贴板编辑。

新输入字形使用增量字体页，保留已上传的中英文图集。分页后仍用同一 HarfBuzz 字体排版，查找器将各字形映射到所属纹理。增量页最多 64 页；单页上限 2048×4096。超出容量或字体不支持时显示缺字框，并在终端记录原因。图集更新在上一帧 fence 完成后执行，不释放仍在使用的纹理。

候选窗口本身由系统输入法提供。本轮自动验证覆盖 SDL 预编辑和提交事件及实际字形回读，不等同于对所有系统输入法的人工验收。

## 扩展下一种语言

1. 在 `EditorLocale`、语言解析和显示名称中增加 locale，例如 `ja-JP`。
2. 扩展消息表，使每个界面消息拥有该 locale 的译文；将译文加入 `editor_language_samples()`。
3. 为该语言选择覆盖完整的字体，运行实际排版后的字形覆盖检查。不能只检查 Unicode 字符，因为 OpenType 连字可能产生新的 glyph ID。
4. 将新 locale 加入状态与截图矩阵，检查最窄面板、弹出菜单、检查器字段和缩略图标签。
5. 需要阿拉伯语等语言时，另行实现段落双向布局、按文本片段选择字体及镜像布局策略。现有 HarfBuzz shaping 不能独自代表完整 RTL UI 支持。

参考：[SDL 文本输入区域](https://wiki.libsdl.org/SDL3/SDL_SetTextInputArea)、[SDL 输入启动与 IME](https://wiki.libsdl.org/SDL3/SDL_StartTextInput)、[FreeType SDF 范围](https://freetype.org/freetype2/docs/reference/ft2-properties.html#spread)。
